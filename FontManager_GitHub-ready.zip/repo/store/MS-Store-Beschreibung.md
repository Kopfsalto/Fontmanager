# Microsoft-Store-Texte für FontManager

> Platzhalter `DEIN-GITHUB-NAME` vor dem Einreichen ersetzen.

---

## App-Name

FontManager by Kopfsalto

## Kurzbeschreibung (max. 100 Zeichen)

Schriften wirklich deinstallieren – sicher, in Masse, mit Vorschau. Kostenlos & Open Source.

## Beschreibung

Windows bietet keine komfortable Möglichkeit, viele Schriftarten auf einmal
wirklich zu deinstallieren. FontManager schließt genau diese Lücke — und
bleibt auch bei Bibliotheken mit über 8.000 Fonts flüssig.

KOSTENLOS & OPEN SOURCE
FontManager ist ein nicht-kommerzielles Hobby-Projekt: dauerhaft kostenlos,
ohne Werbung, ohne In-App-Käufe, ohne Konto und ohne Datensammelei. Der
komplette Quellcode steht unter der freien GPLv3-Lizenz auf GitHub:
https://github.com/DEIN-GITHUB-NAME/FontManager

SICHERHEIT ZUERST
• Windows-11-Systemschriften (Arial, Segoe UI, Calibri …) sind auf drei
  Ebenen fest geschützt und können mit der App niemals gelöscht werden
• Gelöschte Fonts wandern zuerst 30 Tage in einen app-eigenen Papierkorb
  und lassen sich mit einem Klick wiederherstellen
• Automatisches Backup der Font-Registry vor der ersten Änderung

DEINE SCHRIFTEN IM GRIFF
• Kachel-Bibliothek mit Live-Vorschau und eigenem Beispieltext
• Massenauswahl per Checkbox, Strg/Shift, Suche und Filtern
• Filter nach Klassifikation (Serif, Sans, Script, Monospace, Barcode …),
  Schriftsystem (Latein, Arabisch, Kyrillisch, CJK …), Hersteller und Tags
• Echtes Deinstallieren oder nur Deaktivieren/Reaktivieren
• Duplikat-Finder, Defekt-Erkennung, Vergleichsansicht, PDF-Musterkatalog
• Export als ZIP und Sammel-Installation auf anderen Rechnern
• Fonts temporär laden — ohne Installation, nur für die aktuelle Sitzung
• Download frei lizenzierter Schriften aus 4 öffentlichen Quellen
  (Google Fonts, Fontsource, Fontshare, Font Squirrel)
• Modernes Fluent-Design mit Dark- und Light-Mode

PRIVATSPHÄRE
Die App arbeitet vollständig lokal. Internet wird nur genutzt, wenn du
aktiv den Font-Download öffnest. Keine Telemetrie, kein Tracking.

Fragen oder Wünsche? mail@kopfsalto.de

## Feature-Stichpunkte (Store-Feld „Produktfunktionen", max. 20)

1. Schriften wirklich deinstallieren statt nur ausblenden
2. Windows-Systemschriften dreifach geschützt — nie löschbar
3. 30-Tage-Papierkorb mit Ein-Klick-Wiederherstellung
4. Massenauswahl, Suche und leistungsfähige Filter
5. Live-Vorschau-Kacheln mit eigenem Beispieltext
6. Duplikat-Finder und Erkennung defekter Fonts
7. Export/Import ganzer Font-Sammlungen als ZIP
8. Download frei lizenzierter Fonts aus 4 Quellen
9. Dark- und Light-Mode im Fluent-Design
10. 100 % kostenlos, Open Source (GPLv3), keine Werbung

## Weitere Store-Metadaten (Vorschläge)

- **Kategorie:** Dienstprogramme & Tools
- **Preis:** Kostenlos (keine In-App-Käufe)
- **Website:** https://github.com/DEIN-GITHUB-NAME/FontManager
- **Support-Kontakt:** mail@kopfsalto.de
- **Datenschutzerklärung (Pflicht-URL, da die App Internet nutzt):**
  https://github.com/DEIN-GITHUB-NAME/FontManager/blob/main/PRIVACY.md
- **Altersfreigabe:** IARC-Fragebogen → keine bedenklichen Inhalte

## Copyright-/Lizenzhinweis (Store-Feld „Copyright- und Markeninfo")

Copyright © 2026 Kopfsalto. Freie Software unter GNU GPLv3 —
Quellcode: https://github.com/DEIN-GITHUB-NAME/FontManager
