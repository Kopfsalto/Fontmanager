# FontManager 3.3 by Kopfsalto — Projekt-Übergabe

Windows-11-Desktop-Tool zur Verwaltung von ~8500 installierten Schriftarten:
echtes Deinstallieren (nicht nur deaktivieren) mit mehrstufigem Schutz der
Windows-Standardschriften, Papierkorb-Sicherheitsnetz, Metadaten-Filter,
Font-Download aus freien Quellen und modernem Fluent-UI.

- **Autor/Branding:** „Kopfsalto" · Akzentfarbe Crimson `#C5073D`
- **About-Links:** Instagram `instagram.com/kopfsalto` (Anzeige nur
  „Kopfsalto", ohne .de), Twitch `kopfsalto1337`, Ko-Fi `Kopfsalto`,
  Support `mail@kopfsalto.de`
- **Fenstertitel:** `FontManager {VERSION} by Kopfsalto`
- **Nutzung:** privat unter Freunden (relevant für Lizenz, s. u.)

---

## 1. Tech-Stack & Build

| Bereich | Entscheidung |
|---|---|
| Sprache/GUI | Python 3.11+, PySide6, **PySide6-Fluent-Widgets 1.11+** |
| Rendering | Eigenes QListView-Delegate (Kacheln), Pillow für Thumbnails/PDF |
| Font-Analyse | fontTools (lazy, `fontNumber=0` bei .ttc/.otc) |
| Packaging | PyInstaller: `--onefile --windowed --uac-admin --icon FontManager.ico --add-data "FontManager.ico;." --collect-all qfluentwidgets` |
| Build | `build.bat` (Doppelklick) → ruft `build.ps1` (venv + pip + pyinstaller) |

**Lizenzhinweis (wichtig):** PySide6-Fluent-Widgets ist dual-lizenziert —
GPLv3 nur für **nicht-kommerzielle** Nutzung; kommerzieller Vertrieb bräuchte
die Kauflizenz des Autors. Für private Nutzung/Freunde ok (User hat das
bewusst so entschieden). Hinweis steht auch auf der Über-Seite.

## 2. Modul-Übersicht

| Datei | Inhalt |
|---|---|
| `font_manager.py` | Komplette GUI (~3000 Zeilen): Fenster, Seiten, Dialoge, Threads, Theme, Icons, Animationen |
| `font_core.py` | Win32/Registry-Kernlogik: Enumeration, Schutzprüfung, Deinstallation, Papierkorb, Deaktivieren, temporäre Aktivierung, Export/Install, Tags, Settings, Registry-Backup, Datei-Hash |
| `font_meta.py` | fontTools-Analyse: Klassifikation (OS/2 sFamilyClass/PANOSE/post + Namensheuristik), Schriftsysteme (ulUnicodeRange), Hersteller (name-ID 8/9 + Vendor-ID-Map), Defekt-Flag `b`; Meta-Cache `metacache.json` |
| `font_download.py` | 4 freie Quellen ohne API-Key (s. u.), robuste HTTP/JSON-Schicht, Vorschau-Einzeldownload |
| `win11_default_fonts.py` | Whitelist: 364 Dateinamen der Win11-Standardfonts (inkl. FOD-Sprachpakete) |
| `gen_icon.py` | erzeugt FontManager.ico/Logo (Crimson-Verlauf, „Aa", drei Punkte) |
| `build.ps1` / `build.bat` | Build-Pipeline |

**Datenablage:** `%LOCALAPPDATA%\FontManager\` → `Papierkorb\` (+
`manifest.json`), `ThumbCache\`, `Downloads\` (+ `_preview\`),
`RegistryBackup\`, `metacache.json`, `tags.json`, `deaktiviert.json`,
`settings.json` (theme, welcome_shown, tutorial_enabled, trash_days,
sample_text, sidebar-Zustände, win_geometry als Base64-saveGeometry).

## 3. Kernkonzepte (font_core)

- **Dreistufiger Schutz** der Windows-Standardschriften: (1) Whitelist-Abgleich
  Dateiname, (2) `.fon`/`.fnt` immer geschützt, (3) Pfad `C:\Windows\Fonts` +
  Besitzer TrustedInstaller. `check_protected()` läuft **zusätzlich in der
  Kernlogik unmittelbar vor jeder Lösch-/Deaktivier-Aktion** (Defense in
  Depth) — GUI-Markierung allein reicht nie.
- **Löschablauf:** `RemoveFontResourceW`-Schleife → Registry-Werte entfernen
  (HKLM inkl. Wow6432Node best-effort, HKCU) → Datei in Papierkorb; bei
  gesperrter Datei `MoveFileEx(DELAY_UNTIL_REBOOT)` → `WM_FONTCHANGE`.
- **Papierkorb:** 30 Tage (konfigurierbar), Wiederherstellen/endgültig leeren,
  automatisches Aufräumen beim Start.
- **Deaktivieren/Reaktivieren:** Registry-Eintrag raus, Datei bleibt; Zustand
  in `deaktiviert.json`.
- **Temporäre Aktivierung:** `AddFontResourceW` ohne Registry — Session-only,
  beim App-Beenden `temp_deactivate_all()`.
- **Export/Install:** ZIP mit `manifest.json`; Installation „Nur ich"
  (HKCU/User-Fontordner) oder „Alle Benutzer" (Admin); Scope-Anzeige im UI
  heißt bewusst **„Alle Benutzer" / „Nur ich"** (kein HKLM/HKCU-Jargon!).
- **Registry-Backup:** `reg export` beider Fonts-Keys als .reg; automatisch
  beim Erststart, manuell über Sidebar; läuft im Thread (BackupThread).

## 4. Font-Download (font_download.py)

| Quelle | Liste | Download |
|---|---|---|
| Google Fonts | `gwfh.mranftl.com/api/fonts` | `…/api/fonts/{id}?download=zip&formats=ttf` |
| Fontsource | `api.fontsource.org/v1/fonts` | `…/v1/download/{id}` (Fallback: ttf-URLs per Regex aus `/v1/fonts/{id}`) |
| Fontshare | `api.fontshare.com/v2/fonts?offset=&limit=100` (paginiert) | `…/v2/fonts/download/{slug}` |
| Font Squirrel | `fontsquirrel.com/api/fontlist/all` | `fontsquirrel.com/fontfacekit/{urlname}` |

- **Robustheit:** Browser-User-Agent (sonst liefert v. a. Font Squirrel
  HTML-Blockseiten → „Expecting value"-Bug), `utf-8-sig`-Decode (BOM),
  HTML-Antworten werden mit verständlicher Meldung abgefangen.
- **Live-Vorschau im Download-Dialog:** Google/Fontsource liefern günstige
  Einzel-ttf (gecacht in `Downloads/_preview`); Fontshare/Squirrel nur
  Komplett-ZIP → Platzhaltertext. Token-Mechanik verwirft veraltete
  Vorschau-Antworten beim schnellen Durchklicken.
- Pro Familie wählbar: **installieren (nur für mich)** oder **nur temporär
  aktivieren**. DaFont & Co. bewusst ausgeschlossen (keine API, gemischte
  Lizenzen); **Adobe Fonts hat keine öffentliche Download-API** (CC-Sync,
  lizenzgeschützt) — Login-Integration bewusst nicht enthalten.

## 5. UI-Architektur (font_manager.py)

- **Shell:** `MSFluentWindow` (Microsoft-Store-Stil) — kompakte, immer
  sichtbare Icon-Navigation am Fensterrand: **Bibliothek** (oben),
  **Einstellungen** + **Über** (unten, `position=NavigationItemPosition.BOTTOM`
  — bei MSFluentWindow zwingend als Keyword!).
- **Bibliotheks-Seite:** CommandBar oben (enthält NUR „Neu laden"),
  Admin-Banner (falls ohne Adminrechte), Akkordeon-Sidebar links, Kachel-Grid
  rechts, Statuszeile (`status_label`, es gibt KEINE QStatusBar mehr —
  Meldungen über `show_status(msg, timeout)`).
- **Akkordeon-Sidebar** (`CollapsibleSection`, animiert, Zustand persistiert;
  Breite skaliert im resizeEvent: 23 % Fensterbreite, 300–420 px):
  1. Suche & Filter (Suche, Status inkl. „Defekt", Klassifikation,
     Schriftsystem, Hersteller-EditableCombo, Tag, Reset)
  2. Ansicht & Vorschau (Beispieltext, Größe, Sortierung)
  3. Auswahl & Aktionen (Markieren, Vergleichen, Tags ±, Trennlinie,
     Deaktivieren/Reaktivieren, PrimaryPushButton „In den Papierkorb…")
  4. Import & Export (Internet-Download, Export-ZIP, Installieren,
     Temporär laden)
  5. Werkzeuge (Duplikate, Aufräumen, PDF-Katalog, Schrift-Infos,
     Temp entladen, Font-Cache, Tour)
  6. Papierkorb & Sicherung (Papierkorb anzeigen, Sichern, Ordner öffnen)
- **Theme-System:** Token-Dict `THEME` (light/dark) für eigene Malereien
  (Delegate, Overlays) + `build_qss()` **nur QDialog-scoped + eigene IDs**
  (Fluent-Widgets stylen sich selbst — globale QPushButton-Regeln würden sie
  zerstören!) + `setTheme()/setThemeColor()` für Fluent. **Kacheln bleiben in
  beiden Themes weiße „Papier"-Karten** (Schriftmuster-Lesbarkeit).
- **Kachel-Delegate:** Checkbox, Badge (GESCHÜTZT rot / DEFEKT orange /
  DEAKTIVIERT grau / löschbar grün), Lazy-Thumbnail (Pillow, PNG-Disk-Cache,
  Cache-Key enthält Pfad+mtime+Größe+**Beispieltext+px**), Name, Größe/Scope,
  Meta-Zeile mit #Tags.
- **Eigene Vektor-Icons:** `make_icon(name)` zeichnet per QPainter (search,
  eye, check, globe, trash, sun, moon, sparkle, camera, gamepad, cup, mail,
  warn, wrench, shield) — keine Emojis im UI (User-Vorgabe).
- **Erststart-Flow:** `SplashOverlay` (Vollflächen-Overlay IM Fenster, deckt
  ab Frame 1 ab — Animation startet erst im showEvent; Logo-Zoom OutBack,
  „Willkommen", Name+Version, Fade-out, Klick überspringt) → `SetupDialog`
  (Design mit Live-Vorschau, Tour ja/nein, Papierkorb-Tage, Beispieltext) →
  optional Tour.
- **TourOverlay:** abdunkelndes Overlay, Spotlight via **Pfad-Subtraktion**
  (`CompositionMode_Clear` rendert auf Windows SCHWARZ — nie verwenden!),
  klappt auch Eltern-Sektionen des Ziels auf (`expand_instant`), scrollt per
  `ensureWidgetVisible` + `processEvents`, Sprechblase mit
  Anti-Overlap-Platzierung (4 Kandidatenpositionen), folgt Fenstergröße per
  EventFilter, ESC beendet.
- **SuccessPopup:** animierter Haken + Konfetti statt 🎉 — bei reinen
  Erfolgen; Detail-MessageBox nur wenn es Fehler/Übersprungene gibt.
- **Ladeanzeigen:** `StateToolTip` oben rechts bei Sync („n Schriften
  geladen" + Haken), Sicherung und Font-Cache-Erneuerung in Threads
  (BackupThread, CacheRebuildThread) mit StateToolTip,
  `IndeterminateProgressRing` im Download-Dialog beim Listenladen,
  QProgressDialog bei Massenaktionen/Duplikat-Scan/PDF.
- **Fenster-Geometrie:** Erststart zentriert (max. 90 % Screen; finale
  Zentrierung im showEvent — vorher greift die Fluent-Mindestbreite ~935 px
  nicht), danach saveGeometry/restoreGeometry über settings; Fallback auf
  Zentrierung, wenn gespeicherte Position auf keinem Monitor liegt.

## 6. Features (fachlich)

Kachel-Bibliothek mit Filtern/Suche/Sortierung · Massenauswahl
(Checkbox, Strg/Shift, Leertaste) · Löschen mit Papierkorb · Deaktivieren/
Reaktivieren · Duplikat-Finder (Größe→SHA1 + Namensgruppen, „neueste
behalten" markiert) · Defekt-Erkennung · Vergleichsansicht (2–40 Fonts,
eigener Text) · Tags · PDF-Musterkatalog (A4, Pillow, gefilterte Ansicht) ·
Einträge-ohne-Datei-Bereinigung · Export/Bulk-Install · temporäres Laden ·
Download aus 4 freien Quellen · Registry-Backup · Font-Cache-Reset ·
Darkmode · Setup/Tour.

## 7. Wichtige Lessons/Fallstricke (nicht wiederholen!)

1. `CompositionMode_Clear` in Kind-Widgets → schwarz statt transparent.
2. Splash als eigenes Fenster → blockierte danach Eingaben; als Overlay lösen.
3. Globale QSS-Regeln zerstören QFluentWidgets → nur `QDialog`-Scope + IDs.
4. `MSFluentWindow.addSubInterface`: 4. Positionsargument ist `selectedIcon`,
   nicht `position` → Keyword nutzen.
5. Font Squirrel/JSON: ohne Browser-UA kommt HTML; BOM beachten.
6. Zentrieren vor dem ersten `show()` scheitert an Fluent-Mindestbreite.
7. Slicing-Patches am Dateiende können den Theme-Block mitreißen — nach
   großen Patches immer Smoke-Test.
8. Endanwender-Wording: nie HKLM/HKCU/Registry im UI („Alle Benutzer"/„Nur
   ich", „Schriftenliste sichern", „Einträge ohne Datei aufräumen").

## 8. Headless-Smoke-Test (Linux/CI)

```python
# QT_QPA_PLATFORM=offscreen; benötigt: libgl1 libegl1 libxkbcommon0 libdbus-1-3
import os, sys, types
os.environ.setdefault("LOCALAPPDATA", "/tmp/lad")
sys.modules['winreg'] = types.SimpleNamespace(
    HKEY_LOCAL_MACHINE=0, HKEY_CURRENT_USER=1, KEY_READ=0,
    KEY_SET_VALUE=0, REG_SZ=1,
    OpenKey=lambda *a, **k: (_ for _ in ()).throw(OSError()))
import font_core as core
core.enumerate_fonts = lambda: []
core.backup_font_registry = lambda: []
core.has_registry_backup = lambda: True
s = core.load_settings(); s["welcome_shown"] = True; core.save_settings(s)
# dann: QApplication, apply_theme, MainWindow() instanziieren, processEvents
```
Damit wurden Fenster/Seiten/CommandBar, Theme-Umschaltung, Settings-Bindings,
Sync-Tooltip, Backup-Thread und Geometrie-Restore verifiziert.

## 9. Versionshistorie (Kurzform)

1.0 Grundgerüst → 2.0 acht Power-Features + Download + About → 2.1 mehr
Quellen, Squirrel-Fix, Download-Vorschau, Settings → 2.2 Dark/Light-Tokens,
Premium-QSS, Welcome-Animation, Tour → 2.3 Tour-Resize-Fix,
Erststart-Splash → 2.4 Akkordeon-Sidebar → 2.5 Splash als Vollflächen-Overlay
+ SetupDialog → 2.6 Vektor-Icons statt Emojis, SuccessPopup → 2.7
Spotlight-/Scroll-Fix, dynamische Sidebar → 2.8 Endanwender-Wording,
Fluent-Rail-Sidebar-Look, Splash-Timing → 3.0 QFluentWidgets-Migration
(FluentWindow, CommandBar, Seiten) → 3.1 Werkzeuge kategorisiert in Sidebar,
CommandBar nur „Neu laden" → 3.2 MSFluentWindow-Rail + Ladeanzeigen überall →
3.3 Fenster zentriert/Position-Restore.

## 10. Offene Ideen / bekannte Grenzen

- Erster Meta-/Thumbnail-Durchlauf bei 8500 Fonts dauert (Cache macht
  Folgestarts schnell) — evtl. Priorisierung sichtbarer Kacheln.
- Variable Fonts / .ttc-Mehrfachfamilien werden als eine Datei behandelt.
- Fontshare-Download-Endpoint ist best-effort dokumentiert — bei API-Änderung
  greift die Fehlerbehandlung.
- Bei kommerziellem Vertrieb: QFluentWidgets-Lizenz kaufen oder auf das
  frühere eigene Theme (v2.8, lizenzfrei, liegt in der Git-Historie/älteren
  ZIPs) zurück.
